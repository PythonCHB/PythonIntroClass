#! /usr/bin/python
# $Id $
"""\
%prog [options] <agefs_path>

Where:  <agefs_path>    = fully qualified directory name that contains agefs
                          log file someplace within it or its sub directories.

This program will search for agefs log files within the specified path and
merge them in a single filtered and sorted file.  The file is then indexed
producing an associated dictionary file.

Return values:
    0   Test Case results were successfully
    1   Test Case results validation failed
    2   Invalid number of arguments specified
    4   log_path is not a valid directory
    8   Temp file failure
    16  Index creation failure\
"""
import inspect
import sys
import optparse
import os
import pprint
import tempfile
import time

if 'QALIB' in os.environ:
    qalib = os.environ['QALIB']
elif 'QA' in os.environ:
    qalib = os.path.join(os.environ['QA'], "lib")
else:
    qalib = "/usr/local/qa/lib"

sys.path.append(qalib)

from qa.utils  import logger

# Global Private Variables
__AGEFS_FILES       = 0
__FAILURE           = -1
__FILE_NAME_STRIP   = ";,"
__FILE_NAMES        = 0
__FORCE_ASSOCIATION = {}            # See actual definition at end of program
__NO_ASSOCIATIONS   = ["snap_dir:"]
__REVERSE_ACTIONS   = ["link:", "symlink:"]
__SUCCESS           = 0
__TEMP_FILE         = None
__TEST_START        = time.time()

# Global Public Variables
AGEFS_DIRECTORY     = None
CONCATINATED_FILE   = "agefs_cat"
DEBUG               = False
FILTER              = "PASS::"
INDEX               = True
INDEX_ONLY          = False
LOG_DIRECTORY       = None
QUIET               = False
VERBOSE             = False

# Error Codes
ERR_TEST_FAILED     = 1
ERR_INV_ARGS        = 2
ERR_INV_AGEFS_DIR   = 4
ERR_TEMP_FILE       = 8
ERR_INDEX_FAILURE   = 16

def __get_args() :
    """Parse and process command line options and arguments
    @param      None
    @return     integer     result code.
                            0 = successful

    The following is the list of options:

        Format: Key , (Tuple1[], Tuple2, Tuple3, Tuple4)

        Key     = Global variable name to store option in
        Tuple1  = Array of option flags
        Tuple2  = Option type
        Tuple3  = Action to perform
        Tuple4  = Help text

    "CONCATINATED_FILE" , ( ["--concat"],               "str",  "store",
        'Destination file to store the resulting concatinated and sorted '
        'agefs log files. Default: "%default"'
        ),
    "FILTER"            , ( ["--filter"],               "str",  "store",
        'Regular expression (egrep style) used to filter log file records '
        'while merging files. Default: "%default"'
        ),
    "INDEX_ONLY"        , ( ["--index_only"],           None, "store_true",
        'Option used to perform indexing process ONLY. Default: %default'
        ),
    "INDEX"             , ( ["--no_index"],             None, "store_false",
        'Option used to suppress the merge indexing process. Default: %s'
        % (not INDEX)
        ),
    "log_directory"     , ( ["--log_dir"],              "str",  "store",
        'Log Directory path to be used for generated log files. Default: '
        '"%default"'
        )
    """
    global QUIET
    global VERBOSE
    global DEBUG
    global AGEFS_DIRECTORY

    ex = __SUCCESS

    parser = optparse.OptionParser(usage=__doc__)

    my_options = __add_opts_from_doc(parser )
    logger.add_logging_options(parser)

    opts,args = parser.parse_args()

    if len(args) == 1:
        logger.setup_logging(opts)

        if opts.quiet :
            QUIET = True

        if opts.verbose :
            VERBOSE = True

        if opts.debug :
            VERBOSE = True
            DEBUG = True

        if opts.log :
            print "Run Logging: %s" % opts.log

        for opt in my_options :
            globals()[opt.upper()] = getattr(opts, opt)

        if os.path.isdir(args[0]) :
            AGEFS_DIRECTORY = args[0]

        else :
            ex = ERR_INV_AGEFS_DIR
            logger.error("%s is not a valid directory" % args[0])

    else :
        ex = ERR_INV_ARGS
        parser.error("Invalid number of argument(s) specified")

    if ex :
        parser.print_help()

    return ex

def __add_opts_from_doc(parser) :
    """
    Reads the callers __doc__ and adds the specified options to the parser
    """
    # Calling functions __doc__ string
    opts_str = globals()[inspect.stack()[1][3]].__doc__

    # Convert everything starting with the first quot of the __doc__ string
    # to a list replacing newlines with spaces
    options = eval("[%s]" % opts_str[opts_str.find("\""):].replace("\n"," "))

    # Parse the options list
    opt_list = []
    for i, opt in enumerate(options[::2]) :
        opt_list.append(opt)
        flags, otype, action, help = options[(i * 2) + 1]

        if action == "callback" :
            callback = globals()["%s_callback" % opt.lower()]

        else :
            callback = None

        # Add the option to the parser
        parser.add_option(*flags
                        , action=action
                        , callback=callback
                        , default=globals()[opt.upper()]
                        , dest=opt
                        , help=help
                        , type=otype)

    return opt_list

def main() :
    """
    Main processing loop to search, merge, sort and index agefs log files
    """
    ex = __Init()

    # Locate and merge all agefs log files
    if ex == __SUCCESS and INDEX_ONLY == False:
        ex = __append_logs(AGEFS_DIRECTORY, __TEMP_FILE)

    # Sort the merged files
    if ex == __SUCCESS and __AGEFS_FILES > 0 and INDEX_ONLY == False:
        ex = __sort_file(__TEMP_FILE, CONCATINATED_FILE)

    # Index the merged and sorted file
    if ex == __SUCCESS and INDEX and (__AGEFS_FILES > 0 or INDEX_ONLY) :
        ex = __index_file(CONCATINATED_FILE)

    # Delete temp files and report runtime statistics
    ex = __cleanup(ex)

    return ex

def __Init() :
    """Initialize the runtime environment
    @param      None
    @return     integer     result code.
                            0 = successful
    """
    global __TEMP_FILE
    ex = __SUCCESS
    fd = None

    if QUIET == False or VERBOSE :
        print "Run started: %s" % time.asctime(time.localtime(__TEST_START))

    # Create a temporary file to merge agefs file into
    try :
        fd = tempfile.NamedTemporaryFile(delete=False)

    except Exception, e :
        ex = ERR_TEMP_FILE
        logger.error('Unable to create temp file: %s: %s' \
            % (sys.exc_info()[0], sys.exc_info()[1]) )

    else :
        __TEMP_FILE = fd.name
        logger.debug('Temp file created: "%s"' % __TEMP_FILE)

    finally :
        if fd :
            fd.close()

    return ex

def __append_logs(top, dest) :
    """
    Search the specified directory tree for agefs log file so they can be
    merged
    """
    global __AGEFS_FILES

    ex = __SUCCESS
    msg = ""

    # Iterate thru the specified directory tree
    for root, dirs, files in os.walk(top, topdown=False) :
        # Bypass processing of directories that begin with "/."
        if root.find("%s." % os.path.sep) < 0 :
            logger.debug('Searching for agefs log files in "%s"' % root)

            # Evaluate the names of the files within a directory for agefs log
            # file names. e.g. "agefs_......log"
            for name in files :
                # Files with beginning with "agefs_stats" are not log file so
                # ignore
                if name[0:11] == "agefs_stats" :
                    pass

                # Append located agefs log files to the temp file
                elif name[0:6] == "agefs_" and name[-4:] == ".log" :
                    __AGEFS_FILES += 1
                    a_file = os.path.join(root, name)

                    ex = __append_file(a_file, dest)

    return ex

def __append_file(file_in, file_to) :
    """
    Append an agefs file to the temporary hold file
    """
    ex = __SUCCESS
    msg = ""

    logger.info('Merging agefs log file "%s"' % file_in)

    # Use "egrep" to filter a located agefs log file for only the desired
    # records and merge the results into the temporary file
    try :
        ex = os.system("egrep '%s' %s >> %s" % (FILTER, file_in, file_to) )

    except Exception, e:
        ex = e.errno
        msg = ": %s: %s" \
            % (file_in, sys.exc_info()[0], sys.exc_info()[1])

    if ex :
        logger.error('Error(%d) merging agefs file "%s"%s'
            % (ex, file_in, msg))

    return ex

def __sort_file(file_in, file_out) :
    """
    Sort a temporary file by date and time producing the file concatenation file
    """
    ex = __SUCCESS

    logger.info('Sorting merged data "%s" to "%s"' % (file_in, file_out) )

    # Use the "sort" program to sort the temporary file by the date/time fields
    # that begin at the 4th character of the 4th word of each record. The words
    # of a record are delineated with ":"
    try :
        ex = os.system("sort -k 4.4 -t ':' %s > %s" % (file_in, file_out) )

        if ex :
            logger.error('Error(%d) sorting temp file "%s" into "%s"'
                % (ex, file_in, file_out) )

    except Exception, e:
        ex = e.errno
        logger.error('Error sorting file "%s": %s: %s'
            % (file_in, sys.exc_info()[0], sys.exc_info()[1]))

    return ex

def __index_file(file_in) :
    """
    Read all the agefs log records for index evaluation purposes.
    """
    global __FILE_NAMES

    ex = __SUCCESS
    fd = None
    file_dict = {}
    child_assoc = {}
    parent_assoc = {}

    # Open the sorted agefs log file
    try:
        fd = open(file_in, "r")
        loc = 0

        # Analyze each record to index them by embedded file names
        for line in fd :
            words = line[16:].split()
            logger.debug('Input records: %shas words: %s' % (line, words))

            # Insure the general layout of the record appears to be a valid
            # record to be analyzed.
            if len(words) > 3 :
                ex = __analyze_record(line
                                    , words
                                    , loc
                                    , file_dict
                                    , child_assoc
                                    , parent_assoc)

            else :
                ex = ERR_INDEX_FAILURE
                logger.error("Unidentifiable record found: %s" % line)

            if ex :
                break

            loc += len(line)

    except IOError, e :
        ex = ERR_INDEX_FAILURE
        logger.error('Error while indexing sorted file "%s": %s: %s\n'
            % (file_in, sys.exc_info()[0], sys.exc_info()[1]) )

    else :
        __FILE_NAMES = len(file_dict)
        logger.info('Indexing results: Records=%d, Parents=%d, Children=%d'
            % (__FILE_NAMES, len(parent_assoc), len(child_assoc)) )

        ex = __save_dicts(file_in, file_dict, child_assoc, parent_assoc)

    finally :
        if fd :
            fd.close()

    return ex

def __analyze_record(line, words, loc, file_dict, child_assoc, parent_assoc) :
    """
    evaluate the current agefs record to derive file names and associations
    """
    ex          = __SUCCESS
    key         = loc       # Initialize key value to relative record location
    action      = words[2]
    previous    = ""

    # Evaluate each word after the "action" of a record for a file name
    for word in words[3:] :
        # If the word has more than 1 path separation character within it
        # it is assumed to be a file name
        if len(word.split(os.path.sep)) > 1 :
            file_name = word.strip(__FILE_NAME_STRIP)

            # Strip off an existing file name suffix that begins with ":"
            # which is used for ads definitions
            if file_name.find(":") :
                file_name = file_name.split(":")[0]

            logger.debug('Found file name "%s" in record at offset %d'
                % (file_name, loc) )

            # Add the located file name to the file Dictionary using the
            # offset within the file the file name FIRST appeared as it's
            # unique key value.
            if file_name in file_dict :
                file_dict[file_name].append(loc)

            else :
                file_dict[file_name] = [key, loc]

            # When 2 file names exist within the same record and the record
            # action is not excluded, generate parent to child association
            # indexes
            if action not in __NO_ASSOCIATIONS and previous :
                ex = __association(line
                                    , action
                                    , file_dict[file_name][0]
                                    , file_dict[previous][0]
                                    , child_assoc
                                    , parent_assoc)

            previous = file_name

        # Increment key value by word length to constantly generate a unique
        # value
        key += len(word) + 1

    # Process any actions that have "forced" associations
    if ex == __SUCCESS and action in __FORCE_ASSOCIATION :
        ex = __FORCE_ASSOCIATION[action](line
                                        , words
                                        , loc
                                        , file_dict
                                        , child_assoc
                                        , parent_assoc)

    return ex

def __association(line, action, curr_id, prev_id, child_assoc, parent_assoc) :
    """
    Create dictionary entries for the parent and child file names
    """
    ex = __SUCCESS

    # For actions that have reversed associations the first file name located
    # in the record is that Child of the second file name located OTHERWISE
    # the first file name is the Parent of the second file name
    if action in __REVERSE_ACTIONS :
        logger.debug('Reversing file association')
        p_id = curr_id
        c_id = prev_id

    else :
        p_id = prev_id
        c_id = curr_id

    # Add child associations to it's parent
    if p_id in child_assoc :
        child_assoc[p_id].append(c_id)
        logger.debug('Child added: parent=%d, child=%s'
            % (p_id, child_assoc[p_id]) )

    else :
        child_assoc[p_id] = [c_id]
        logger.debug('Child created: parent=%d, child=%d' % (p_id, c_id) )

    # Add parent association to it's child.
    #   NOTE: There should only ever be 1 parent associated to a child
    if c_id in parent_assoc :
        ex = ERR_INDEX_FAILURE
        logger.info('Parent=%d existing parent=%s, child=%d'
            % (p_id, parent_assoc[c_id], c_id) )
        logger.error('Child record derrived multiple parrents: %s' % line)

    else :
        parent_assoc[c_id] = [p_id]
        logger.debug('Parent created: parent=%d, child=%d' % (p_id, c_id) )

    return ex

def __save_dicts(file_in, file_dict, child_assoc, parent_assoc) :
    """
    Save the created file, child association, and parent association
    dictionaries
    """
    ex = __SUCCESS
    fd_out = None

    # Save the index Dictionaries in a file
    try :
        fd_out = open("%s_dict.py" % file_in, "w")
        fd_out.write("FILE_DICT = %s\n" % pprint.pformat(file_dict))
        fd_out.write("CHILD_ASSOC = %s\n" % pprint.pformat(child_assoc))
        fd_out.write("PARENT_ASSOC = %s\n" % pprint.pformat(parent_assoc))

    except IOError, e :
        ex = ERR_INDEX_FAILURE
        logger.error('Error while writing index file "%s.dict": %s: %s\n'
            % (file_in, sys.exc_info()[0], sys.exc_info()[1]) )

    finally :
        if fd_out :
            fd_out.close()

    return ex

def __mkdir_associate(line, words, loc, file_dict, child_assoc, parent_assoc) :
    """
    Force create association between child and parent directories
    """
    ex          = __SUCCESS
    file_name   = words[-1]
    p_path      = os.path.dirname(file_name)

    # A mkdir action specifies only the Child file name so the parent is
    # derived from the path directory name of the Child
    if p_path in file_dict :
        file_dict[p_path].append(loc)

        ex = __association(line
                            , "mkdir:"
                            , file_dict[file_name][0]
                            , file_dict[p_path][0]
                            , child_assoc
                            , parent_assoc)

    return ex

def __cleanup(last_exit) :
    """
    Delete temp files and report runtime statistics
    """
    ex = last_exit

    logger.info('Removing temp file "%s"' % __TEMP_FILE )

    # Delete the temporary file used to merge agefs files
    try :
        os.remove(__TEMP_FILE)

    except Exception, e:
        ex = e.errno
        logger.error('Error removing temp file "%s": %s: %s'
            % (__TEMP_FILE, sys.exc_info()[0], sys.exc_info()[1]))

    now = time.time()

    # Report runtime statistics
    if QUIET == False or VERBOSE :
        print "\n========================================="

    if QUIET == False :
        print "Total agefs logs merged : %s" % __AGEFS_FILES
        print "Records filtered for    : %s" % FILTER
        print "Final sorted file       : %s" % CONCATINATED_FILE
        print "File names indexed      : %s" % __FILE_NAMES

        e = time.gmtime(now - __TEST_START)
        print "Total run time          : %d days, %d:%02d:%02d" \
            % ((e[7] - 1), e[3], e[4], e[5])

    if QUIET == False or VERBOSE :
        print "Completion Status       : ",

        if ex :
            print "Failed (%d)" % ex
        else :
            print "Success"

        print "=========================================\n"
        print "Run Completed: %s" % time.asctime(time.localtime(now))

    logger.info("Terminated: exit=%d" % ex)

    return ex

# Internal referential private variables
__FORCE_ASSOCIATION = {"mkdir:" : __mkdir_associate}

# Program initiation
if __name__ == "__main__":

    ex = __get_args()

    if ex == __SUCCESS :
        ex = main()

    logger.shutdown()

    sys.exit(ex)

