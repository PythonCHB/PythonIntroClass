#! /usr/bin/python
# $Id $
"""\
%prog [options] <file> ...

Where:  <file>  = Fully qualified file name to be reported.

This program will report full modification history of a file. All log records
created from agefs will be rendered related to the file that is specified. The
concatenated agefs log and dictionary files are used the source database.

Return values:
    0   Test Case results were successfully
    1   Test Case results validation failed
    2   Invalid argument specified
    4   Index file processing failure
    8   Concatenated agefs file processing failure\
"""
import inspect
import sys
import optparse
import os
import time

if 'QALIB' in os.environ:
    qalib = os.environ['QALIB']
elif 'QA' in os.environ:
    qalib = os.path.join(os.environ['QA'], "lib")
else:
    qalib = "/usr/local/qa/lib"

sys.path.append(qalib)

from qa.utils  import logger

# Global Private Variables
__CAT_FD            = None
__CHILD_ASSOC       = {}
__CURR_DEPTH        = 0
__FAILURE           = -1
__FILE_DICT         = {}
__FILE_INDEX        = {}
__FILTER            = []
__FIRST_DEPTH       = None
__PARENT_ASSOC      = {}
__PATH_PARENT       = None
__SPECIAL_FORMAT    = { "*default*" :   "f",
                        "append"    :   "s",
                        "chmod"     :   "p",
                        "chown"     :   "p",
                        "link"      :   "0",
                        "modperf"   :   "p",
                        "modprot"   :   "p",
                        "overwrite" :   "s",
                        "read"      :   "s",
                        "readdir"   :   "s",
                        "snap_dir"  :   "s",
                        "stat"      :   "s",
                        "symlink"   :   "0",
                        "traverse"  :   "s",
                        "trunc"     :   "s"
                        }
__SUCCESS           = 0
__TEST_START        = time.time()

# Global Public Variables
CHILD_DEPTH         = 0
CONCATENATED_FILE   = "agefs_cat"
DEBUG               = False
FILE_NAMES          = None
FILTER              = "copy, mkdir, read, readdir, stat, traverse"
LEVEL               = 1
LOG_DIRECTORY       = None
PARENT_DEPTH        = -1
QUIET               = False
SELF_EMPHASIS       = "."
SHOW_PATH           = True
REVERSE             = False
VERBOSE             = False

# Error Codes
ERR_INDEX_NOTFOUND  = 1
ERR_INV_ARGS        = 2
ERR_INDEX_FILE      = 4
ERR_CAT_FILE        = 8

def __get_args() :
    """Parse and process command line options and arguments
    @param      None
    @return     integer     result code.
                            0 = successful

    The following is the list of options:

        Format: Key , (Tuple1[], Tuple2, Tuple3, Tuple4)

        Key     = Global variable name to store option in
        Tuple1  = Array of option flags
        Tuple2  = Option type
        Tuple3  = Action to perform
        Tuple4  = Help text

    "CHILD_DEPTH"       , ( ["--child_depth"],          "int",  "store",
        'Number of child file relationships to be reported for the specified '
        'file. Specifying a negative number will report ALL relationships. '
        'Default: %default'
        ),
    "CONCATENATED_FILE" , ( ["--concat"],               "str",  "store",
        'Destination file to store the resulting concatenated and sorted '
        'agefs log files. Default: "%default"'
        ),
    "SELF_EMPHASIS"     , ( ["--emphasis"],             "str",  "callback",
        'A single character string to be used to emphasis the specified file '
        'creation within the rendered history tree. Default "%default"'
        ),
    "SHOW_PATH"         , ( ["--no_path_report"],       None,   "store_false",
        'Prevents the path report associated with the specified file from '
        'being printed'
        ),
    "PARENT_DEPTH"      , ( ["--parent_depth"],         "int",  "store",
        'Number of parent file relationships to be reported for the specified '
        'file. Specifying a negative number will report ALL relationships. '
        'Default: %default'
        ),
    "LEVEL"             , ( ["--report_level"],         "int",  "callback",
        'Level of detail to be reported from the agefs log records. Level 0 '
        'reports time, action and file information. Level 1 reports date, '
        'time, action and file information. Level 2 reports status, pid, date, '
        'time, action and file information. Level 3 reports the complete '
        'contents of the log record. Default: %default'
        ),
    "REVERSE"           , ( ["--reverse"],              None,   "store_true",
        'Reverses the reporting order.  The report is normally in chronological '
        'date/time order. This option will cause reverse chronological ordering '
        'to be used.'
        ),
    "FILTER"            , ( ["--suppressed"],           "str",  "callback",
        'Comma separated list of actions to be suppressed from the output. '
        'NOTE: Actions that creates files that are within the linage of the '
        'requested file to be reported are NOT filtered. Default: "%default"'
        ),
    "log_directory"     , ( ["--log_dir"],              "str",  "store",
        'Log Directory path to be used for generated log files. Default: '
        '"%default"'
        )
    """
    global QUIET
    global VERBOSE
    global DEBUG
    global FILE_NAMES

    ex = __SUCCESS

    parser = optparse.OptionParser(usage=__doc__)

    my_options = __add_opts_from_doc(parser)
    logger.add_logging_options(parser)

    opts,args = parser.parse_args()

    if len(args) >= 1:
        logger.setup_logging(opts)

        if opts.quiet :
            QUIET = True

        if opts.verbose :
            VERBOSE = True

        if opts.debug :
            VERBOSE = True
            DEBUG = True

        if opts.log :
            print "Run Logging: %s" % opts.log

        for opt in my_options :
            globals()[opt.upper()] = getattr(opts, opt)

        FILE_NAMES = args

    else :
        ex = ERR_INV_ARGS
        parser.error("Invalid number of argument(s) specified")

    if ex :
        parser.print_help()

    return ex

def __add_opts_from_doc(parser) :
    """
    Reads the callers __doc__ and adds the specified options to the parser
    """
    # Calling functions __doc__ string
    opts_str = globals()[inspect.stack()[1][3]].__doc__

    # Convert everything starting with the first quot of the __doc__ string
    # to a list replacing newlines with spaces
    options = eval("[%s]" % opts_str[opts_str.find("\""):].replace("\n"," "))

    # Parse the options list
    opt_list = []
    for i, opt in enumerate(options[::2]) :
        opt_list.append(opt)
        flags, otype, action, help = options[(i * 2) + 1]

        if action == "callback" :
            callback = globals()["%s_callback" % opt.lower()]

        else :
            callback = None

        # Add the option to the parser
        parser.add_option(*flags
                        , action=action
                        , callback=callback
                        , default=globals()[opt.upper()]
                        , dest=opt
                        , help=help
                        , type=otype)

    return opt_list

def filter_callback(option, opt_str, value, parser) :
    """
    Parser callback to validate the command line option
    """
    if value.lower() in ["none", "off"] :
        new_val = ""

    else :
        new_val = value

    setattr(parser.values, option.dest, new_val)


def level_callback(option, opt_str, value, parser) :
    """
    Parser callback to validate the command line option
    """
    if value in range(4) :
        setattr(parser.values, option.dest, value)

    else :
        raise optparse.OptionValueError(
            "Level must be between 0 and 3 inclusively, found %s" % value)


def self_emphasis_callback(option, opt_str, value, parser) :
    """
    Parser callback to validate the command line option
    """
    if len(value) == 1 :
        setattr(parser.values, option.dest, value)

    else :
        raise optparse.OptionValueError(
            'Self Emphasis must be exactly 1 byte, found "%s"' % value)


def main() :
    """
    Main processing loop
    """
    global CHILD_DEPTH
    global __PATH_PARENT

    ex = __Init()

    if ex == __SUCCESS :
        # Process each specified file name
        for file_name in FILE_NAMES :
            if file_name in __FILE_DICT :
                # Determine files parent path ID
                path = os.path.dirname(file_name)
                if path in __FILE_DICT :
                    __PATH_PARENT = __FILE_DICT[path][0]

                # Derive and print the file's linage tree
                ex = __print_linage(file_name)

                # Print parent path linage if parent path not already printed
                if ex == __SUCCESS and __PATH_PARENT and SHOW_PATH:
                    hold_depth = CHILD_DEPTH
                    CHILD_DEPTH = 0
                    ex = __print_linage(path)
                    CHILD_DEPTH = hold_depth
                    __PATH_PARENT = None

            else :
                ex = ERR_INDEX_NOTFOUND
                logger.error('Index for File name "%s" does not exist'
                    % file_name )

            if ex > ERR_INDEX_NOTFOUND :
                break

    ex = __cleanup(ex)

    return ex

def __Init() :
    """Initialize the runtime environment
    @param      None
    @return     integer     result code.
                            0 = successful
    """
    global __CAT_FD
    global __FILE_INDEX
    global __FILTER
    global PARENT_DEPTH

    ex = __SUCCESS

    if QUIET == False or VERBOSE :
        print "Run started: %s" % time.asctime(time.localtime(__TEST_START))

    PARENT_DEPTH *= -1

    for word in FILTER.split(",") :
        __FILTER.append(word.strip())

    ex = __load_dicts()

    if ex == __SUCCESS :
        # Create a reverse index to file name dictionary keyed on file name key
        for file_name in __FILE_DICT :
            key = __FILE_DICT[file_name][0]
            if key in __FILE_INDEX :
                ex = ERR_INDEX_FILE
                logger.error(
                    'File name "%s" has duplicate index(%d) to file "%s"'
                    % (file_name, key, __FILE_INDEX[key]) )

            else :
                __FILE_INDEX[key] = file_name

        logger.info('File name indexes built: %d entries' % len(__FILE_INDEX))

    if ex == __SUCCESS :
        try:
            # Open the concatenated agefs action file to random access
            __CAT_FD = open(CONCATENATED_FILE)

        except IOError, e :
            ex = ERR_CAT_FILE
            logger.error('Error opening concatenated agefs file(%d) "%s": %s'
                % (e.errno, CONCATENATED_FILE, e.strerror) )

    return ex

def __load_dicts() :
    """
    Import the concatenated agefs log file's index dictionary
    """
    global __CHILD_ASSOC
    global __FILE_DICT
    global __PARENT_ASSOC

    ex = __SUCCESS

    try : 
        exec("import %s_dict" % CONCATENATED_FILE)
        __FILE_DICT = eval("%s_dict.FILE_DICT" % CONCATENATED_FILE)
        __CHILD_ASSOC = eval("%s_dict.CHILD_ASSOC" % CONCATENATED_FILE)
        __PARENT_ASSOC = eval("%s_dict.PARENT_ASSOC" % CONCATENATED_FILE)

    except Exception :
        ex = ERR_INDEX_FILE
        logger.error('Failure loading index dictionaries: %s: %s'
            % (sys.exc_info()[0], sys.exc_info()[1]) )

    else :
        logger.info('File Dictionary loaded with %d file names\n'
            'Forward Reference Associations loaded with %d parents\n' 
            'Backward Reference Associations loaded with %d children\n'
            % (len(__FILE_DICT), len(__CHILD_ASSOC), len(__PARENT_ASSOC)) )

    return ex

def __print_linage(file_name, file_type="" ) :
    """
    Print the linage of the specified file or path per the ordering option
    """
    global __FIRST_DEPTH

    ex              = __SUCCESS
    __FIRST_DEPTH   = None

    print "\nAGEFS Actions related to %s %s\n" % (file_name, file_type)

    # Derive and print the file's linage tree
    if REVERSE :
        ex = __derive_linage_r(__FILE_DICT[file_name][0], None)

    else :
        ex = __derive_linage(__FILE_DICT[file_name][0], None)

    print

    return ex

def __derive_linage_r(start_id, end_id) :
    """
    Print the specified file's parent and child linage in reverse time sequence

    Definition of Terms:
        Spawning Record =   An agefs actions the creates a new file. Actions
                            such as create, copy, move, link, mkdir, clone,
                            etc. are considered spawning records.
        Parent          =   Agefs spawning record that created the current
                            record being processed.
        Child           =   Agefs spawning record that is created by the
                            current record being processed.
        Linage          =   An entire line of parent and/or child associations.
    """
    ex = __SUCCESS

    logger.debug('Reporting action from ID:%s to ID:%s' % (start_id, end_id))

    child_recs = __load_child_dict(start_id)

    # Obtain the spawning agefs record offset for the passed "last" file ID to
    # print
    if end_id :
        end_rec = __FILE_DICT[__FILE_INDEX[end_id]][1]
        print_it = False

    else :
        print_it = True

    # Obtain the spawning agefs record offset for the passed "current" file ID
    # to print
    first_rec = __FILE_DICT[__FILE_INDEX[start_id]][1]

    # Print every agefs record associated the "current" file ID being processed
    # in reverse order
    for record in __FILE_DICT[__FILE_INDEX[start_id]][:0:-1] :
        if print_it :
            # Process current record and its children
            ex = __child_linage(start_id, record, child_recs, first_rec)

        # Start printing if we have reached the "last" file ID's spawning record
        if end_id and record == end_rec :
            print_it = True

        if ex :
            break

    if ex == __SUCCESS :
        ex = __parent_linage(start_id)

    return ex

def __derive_linage(start_id, end_id) :
    """
    Print the specified file's parent and child linage in time sequence

    Definition of Terms:
        Spawning Record =   An agefs actions the creates a new file. Actions
                            such as create, copy, move, link, mkdir, clone,
                            etc. are considered spawning records.
        Parent          =   Agefs spawning record that created the current
                            record being processed.
        Child           =   Agefs spawning record that is created by the
                            current record being processed.
        Linage          =   An entire line of parent and/or child associations.
    """
    ex              = __SUCCESS

    logger.debug('Reporting action from ID:%s to ID:%s' % (start_id, end_id))

    child_recs = __load_child_dict(start_id)
    ex = __parent_linage(start_id)

    # Obtain the spawning agefs record offset for the passed "last" file ID to
    # print
    if end_id :
        end_rec = __FILE_DICT[__FILE_INDEX[end_id]][1]

    # Obtain the spawning agefs record offset for the passed "current" file ID
    # to print
    first_rec = __FILE_DICT[__FILE_INDEX[start_id]][1]

    # Print every agefs record associated the "current" file ID being processed
    for record in __FILE_DICT[__FILE_INDEX[start_id]][1:] :
        # Stop printing if we have reached the "last" file ID's spawning record
        if ex or (end_id and record == end_rec) :
            break

        # Process current record and its children
        ex = __child_linage(start_id, record, child_recs, first_rec)

    return ex

def __load_child_dict(child) :
    """
     When child reporting is requested:
        create a dictionary of children for this current level for reference
        in the main reporting loop
    """
    child_recs = {}

    if __CURR_DEPTH > -1 and (CHILD_DEPTH < 0 or CHILD_DEPTH > __CURR_DEPTH) \
        and child in __CHILD_ASSOC :
        logger.debug('child IDs found: %s' % __CHILD_ASSOC[child])
        for c_id in __CHILD_ASSOC[child] :
            child_recs[__FILE_DICT[__FILE_INDEX[c_id]][1]] = c_id

        logger.debug('Child records found: %s' % child_recs)

    return child_recs

def __child_linage(me_id, me_record, child_recs, first_rec) :
    """
    Process child linage if current record is a child spawning record otherwise
    report the current record data
    """
    global __CURR_DEPTH

    ex = __SUCCESS

    # Process any children
    if me_record in child_recs :
        child = child_recs[me_record]
        logger.debug('Record ID:%d has child ID:%d' % (me_id, child) )

        __CURR_DEPTH += 1
        ex = __derive_linage(child, None)
        __CURR_DEPTH -= 1

    else :
        # Read, format, and print the current agefs record
        ex = __report(me_id, me_record, me_record == first_rec)

    return ex

def __parent_linage(child) :
    """
    When parental linage is requested:
        process all parents before printing "self" or children linage

    NOTE: Negative depth values indicate parental linage
    """
    global __CURR_DEPTH

    ex = __SUCCESS

    if __CURR_DEPTH < 1 and (PARENT_DEPTH > 0 or PARENT_DEPTH < __CURR_DEPTH) \
        and child in __PARENT_ASSOC :
        parent = __PARENT_ASSOC[child][0]
        logger.debug('Record ID:%d has parent ID:%d' % (child, parent) )

        __CURR_DEPTH -= 1
        ex = __derive_linage(parent, child)
        __CURR_DEPTH += 1

    return ex

def __report(rec_id, rec_loc, spawned) :
    """
    Read the indexed agefs log record to be printed
    """
    global __PATH_PARENT

    ex = __SUCCESS

    logger.debug('Read record at %d, depth=%d' % (rec_loc, __CURR_DEPTH) )
    try :
        # Read the agefs record
        __CAT_FD.seek(rec_loc)
        line = __CAT_FD.readline().strip()

    except IOError, e :
        ex = ERR_CAT_FILE
        logger.error('Error reading concatenated agefs file(%d) "%s": %s'
            % (e.errno, CONCATENATED_FILE, e.strerror) )

    else :
        # Parse out the action and format/print it
        action = line[41:].split(":")[0]
        if spawned == False and action in __FILTER :
            pass

        else :
            __format(line, action, spawned)

            if spawned and rec_id == __PATH_PARENT :
                __PATH_PARENT = None

    return ex

def __format(line, action, spawned) :
    """
    Format the agefs log record based upon the report_level option
    """
    global __FIRST_DEPTH

    if LEVEL < 3 :
        ads     = -1                        # ADS file number, -1 = None
        pre     = []                        # Line prefix words
        files   = []                        # Line files
        suff    = []                        # Line suffix words
        line_l  = []
        line    = line.split(" -l /")[0]    # Eliminate action's log file
        state   = line[[27, 16, 0][LEVEL]:35]
        words   = line[(43 + len(action)):].split()

        # Parse out the agefs line prefix data, file names, and suffix data
        for word in words :
            # If os path is found in the word more that 1 time
            # we assume word is a file name
            if len(word.split(os.path.sep)) > 1 :
                # Keep track of ADS file names
                if word.find(":") >= 0 :
                    ads = len(files)

                files.append(word)
                suff = []

            elif len(files) == 0 :
                pre.append(word)

            else :
                suff.append(word)

        if action in __SPECIAL_FORMAT :
            fmt = __SPECIAL_FORMAT[action].lower()

        else :
            fmt = __SPECIAL_FORMAT["*default*"].lower()

        # Actions against ADS files, always report ADS file name
        if ads >= 0 and files[ads].split(":")[1] :
            line_l.append("ADS=%s" % files[ads].split(":")[1])
            # Remove ADS file names to prevent duplicate reporting
            files.pop(ads)

        # "p" indicates to print line prefix data
        if "p" in fmt and pre :
            line_l += pre

        # "f" indicates to print "final file" name from the line
        if "f" in fmt and files:
            line_l.append(files[len(files) - 1])

        else :
            # "0" indicates print first file name from the line
            if "0" in fmt and files:
                line_l.append(files[0])

            # "1" indicated print the second file name from the line
            if "1" in fmt and len(files) > 1 :
                if "0" in fmt :
                    line_l += ["to", files[1]]

                else :
                    line_l.append(files[1])

        # "s" indicates to print the line suffix data
        if "s" in fmt and suff :
            line_l += suff

        line = "%s: %s: %s" % (state, action, " ".join(line_l))

    # Store the depth of the first item printed
    if __FIRST_DEPTH is None :
        __FIRST_DEPTH = __CURR_DEPTH

    # Generate the proper chart indentation for the current depth
    chart = "|   " * abs(__FIRST_DEPTH - __CURR_DEPTH)

    # Spawned parents and children need an appropriate parent pointer
    if spawned and chart:
        if REVERSE and __CURR_DEPTH < 1 :
            chart = chart[:-3] + "<--"

        else :
            if __CURR_DEPTH == 0 :
                chart = chart[:-3] + ">>>"
                chart = chart.replace(" ",SELF_EMPHASIS)

            else :
                chart = chart[:-3] + "-->"

    # Print the record
    print "%s%s\n" % (chart, line),

    return

def __cleanup(last_exit) :
    """
    Close files and print statistics
    """
    ex = last_exit

    if __CAT_FD :
        __CAT_FD.close()

    now = time.time()

    if QUIET == False or VERBOSE :
        print "\n========================================="

    if QUIET == False :
        print "Concatinated agefs file : %s" % CONCATENATED_FILE
        print 'Actions suppressed      : "%s"' % FILTER
        print "Parent Depth reported   : %s" % (PARENT_DEPTH * -1)
        print "Child Depth reported    : %s" % CHILD_DEPTH
        print "Reporting level provided: %s" % LEVEL

        e = time.gmtime(now - __TEST_START)
        print "Total run time          : %d days, %d:%02d:%02d" \
            % ((e[7] - 1), e[3], e[4], e[5])

    if QUIET == False or VERBOSE :
        print "Completion Status       : ",

        if ex :
            print "Failed (%d)" % ex
        else :
            print "Success"

        print "=========================================\n"
        print "Run Completed: %s" % time.asctime(time.localtime(now))

    logger.info("Terminated: exit=%d" % ex)

    return ex

if __name__ == "__main__":

    ex = __get_args()

    if ex == __SUCCESS :
        ex = main()

    logger.shutdown()

    sys.exit(ex)

