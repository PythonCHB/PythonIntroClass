#!/usr/bin/env python

from mutagen.mp3 import MP3
from mutagen.easyid3 import EasyID3
from mutagen.id3 import ID3, TIT2
import os
import sys
from time import sleep
import time
import soundcloud

date_today = time.strftime('%m-%d-%Y')


colors = {
    'blue':     '\033[0;34m',
    'green':    '\033[0;32m',
    'cyan':     '\033[0;36m',
    'red':      '\033[0;31m',
    'purple':   '\033[0;35m',
    'yellow':   '\033[0;33m',
    'dark gray': '\033[1;30m',
    'normal':   '\033[0m'
}


#define the format for file renaming
def rename_format(a, b, c):
    newfilename = a + "_" + b + "_" + c + ".mp3"
    return newfilename


#check for empty input
def empty_check(prompt):
    loop = True
    while loop is True:
        user_input = raw_input(prompt)
        if not user_input:
            print 'Input is required'
            continue
        else:
            loop = False
        return user_input


#define the menu selections created from directories in the path
def path_menu(tag):
    pathopts = path.split(os.sep)
    pathopts = filter(None, pathopts)
    print "Select an %s name for this fileset:" % tag
    for index, item in enumerate(pathopts):
        print "[" + colors['cyan'] + str(index + 1) + colors['normal'] + "] " + item
    print "[%sM%s] Manual entry (%s not listed)" % (colors['cyan'], colors['normal'], tag)
    path_sel = raw_input("[1]-[%i] or [M]: " % len(pathopts)).lower()
    if path_sel == "m":
        path_in = raw_input("%s for this directory: " % tag)
    else:
        path_in = pathopts[(int(path_sel) - 1)]
    return path_in


#define a function for confirmation. Lifted from http://code.activestate.com/recipes/541096-prompt-the-user-for-confirmation/
def confirm(prompt=None, resp=False):
    if prompt is None:
        prompt = "Confirm"
    if resp:
        prompt = '%s [%s]|%s: ' % (prompt, 'y', 'n')
    else:
        prompt = '%s [%s]|%s: ' % (prompt, 'n', 'y')
    while True:
        ans = raw_input(prompt)
        if not ans:
            return resp
        if ans not in ['y', 'Y', 'n', 'N']:
            print '%sPlease enter y or n.%s' % (colors['red'], colors['normal'])
            continue
        if ans == 'y' or ans == 'Y':
            return True
        if ans == 'n' or ans == 'N':
            return False

confirm_tag = False
while confirm_tag is not True:

#clear screen
    os.system('clear')

#establish the working directory where the audio files are located
    if len(sys.argv) > 1:
        print 'Using passed argument'
        path = os.path.abspath(sys.argv[1]) + "/"

    else:
        nopath = True
        print '%sNo argument passed, using current directory%s' % (colors['yellow'], colors['normal'])
        while nopath is True:
#            path = os.getcwd() + "/"
            print 'Working directory is %s' % (os.getcwd() + '/')
            pathconfirm = "blah"
            if confirm(prompt='Is this correct? ', resp=True) is False:
                path = raw_input("Enter full path to files: ")
                path = os.path.abspath(path) + "/"
                if os.path.exists(path):
                    print "Setting working path to %s" % path
                    nopath = False
                else:
                    print "%sPath does not exist!!!%s" % (colors['red'], colors['normal'])
                    nopath = True
            else:
                path = os.getcwd() + "/"
                nopath = False

#get a list of files in the working directory
#create a list of only mp3 files and sort them
    files = os.listdir(path)

#initialize our list of dictionaries to hold all track info
    tracks = []

    for i in files:
        if '.mp3' in i.lower():
            tracks.append({'orig_fname': i})
            for i in tracks:
                i['orig_fpath'] = path + i['orig_fname']
#clear screen
    os.system('clear')

#check if there are MP3s in the path, if so, display them
    if not tracks:
        while raw_input(("%sNo MP3 files found in path!%s\nPress [enter] to continue") % (colors['red'], colors['normal'])) not in (""):
            break
    else:
        print "%sMP3 files found in %s:%s" % (colors['yellow'], path, colors['normal'])
        for i in tracks:
            print colors['cyan'] + (i["orig_fname"]) + colors['normal']
        confirm_tag = confirm(prompt='Tag these files? ', resp=True)

#clear screen
os.system('clear')

#establish artist name
artist_in = path_menu("artist")
os.system('clear')
print "%sArtist name set to %s%s" % (colors['yellow'], artist_in, colors['normal'])

#establish album name
album_in = path_menu("album")

os.system('clear')
print "%sAlbum name set to %s%s" % (colors['yellow'], album_in, colors['normal'])

rename_files = confirm(prompt='Rename files after tagging? ', resp=True)

#use mutagen to tag the files
for trx in tracks:
#open the mp3 and write a tag in case any don't exist
    audio = MP3(path + trx['orig_fname'])
    audio["TIT2"] = TIT2(encoding=3, text=["Title"])
    audio.save()
#write the tags
    audio = EasyID3(path + trx['orig_fname'])
    audio["artist"] = u"%s" % (artist_in)
    trx['artist'] = artist_in
    audio["album"] = u"%s" % (album_in)
    trx['album'] = album_in
    song_in = str(empty_check("New song title for %s%s%s: " % (colors['cyan'], trx['orig_fname'], colors['normal'])))
    audio["title"] = u"%s" % (song_in)
    trx['title'] = song_in
    audio.save()
    oldfile = os.path.join(path, trx["orig_fname"])
#determine whether file has been renamed for upload
    if rename_files is True:
        trx['new_fname'] = (rename_format(trx['artist'], trx['album'], trx['title']))
        newfilepath = os.path.join(path, trx['new_fname'])
        print "Renaming file from %s%s%s to %s%s%s" % (colors['cyan'], trx['orig_fname'], colors['normal'], colors['purple'], trx['new_fname'], colors['normal'])
        sleep(0.5)
        os.rename(oldfile, newfilepath)
        trx['new_fpath'] = newfilepath
        trx['sc_uppath'] = newfilepath
    else:
        print "%s%s not renamed%s" % (colors['yellow'], trx['orig_fname'], colors['normal'])
        trx['sc_uppath'] = oldfile
        sleep(0.5)
#        tracks[filename].append(path + filename)
os.system('clear')


#upload to sound cloud - this info contains the credentials for the dummy SC account I created
if confirm("Would you like to upload these files to Soundcloud? ", resp=True):
    client = soundcloud.Client(client_id='895a806976b7360e64e263b79e780d96',
                               client_secret='42b61a98675e56c212b9c9d95cf06c3a',
                               username='misterblister@thelittleblackbottles.com',
                               password='python')
    print "Connected to SoundCloud as user " + colors['purple'] + client.get('/me').username + colors['normal']

# upload each audio file
    for trx in tracks:
        print '%sUploading track %s...' % (colors['yellow'], trx['sc_uppath']) + colors['normal']
        track = client.post('/tracks',
                            track={
                            'title': "%s-%s-%s-%s" % (trx['artist'], trx['album'], trx['title'], date_today),
                            'asset_data': open(trx['sc_uppath'], 'rb')
                            })
        trx['sc_id'] = (track.id)
        print 'Track %s%s%s uploaded to %s%s%s' % (colors['cyan'], trx['sc_uppath'], colors['normal'],  colors['purple'], track.permalink_url, colors['normal'])
        trx['sc_url'] = track.permalink_url

    print colors['yellow'] + "File upload to Soundcloud complete" + colors['normal']
